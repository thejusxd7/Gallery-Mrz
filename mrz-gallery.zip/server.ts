import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { Client, GatewayIntentBits, Partials, ActivityType } from "discord.js";
import dotenv from "dotenv";
import { DiscordMessage, BotConfig, BotStatus, LogEntry, RealtimePayload } from "./src/types";
// Firebase Admin SDK core imports
import admin from "firebase-admin";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Resolve directories
let currentDir = "";
try {
  currentDir = path.dirname(fileURLToPath(import.meta.url));
} catch (e) {
  currentDir = __dirname;
}

const DATA_DIR = path.join(currentDir, "data");
const CONFIG_PATH = path.join(DATA_DIR, "config.json");
const MESSAGES_PATH = path.join(DATA_DIR, "messages.json");
const UPLOADS_DIR = path.join(DATA_DIR, "uploads");

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Ensure uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Initialize Firestore (Cloud Database)
let db: any = null;
try {
  const firebaseConfigPath = path.join(currentDir, "firebase-applet-config.json");
  if (fs.existsSync(firebaseConfigPath)) {
    const rawConfig = fs.readFileSync(firebaseConfigPath, "utf-8");
    const firebaseConfig = JSON.parse(rawConfig);
    
    // Check if firebase-admin has already been initialized
    if (admin.apps.length === 0) {
      admin.initializeApp({
        projectId: firebaseConfig.projectId,
      });
    }
    
    // Access the database, supplying custom Database ID if present
    if (firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== "(default)") {
      db = admin.firestore(firebaseConfig.firestoreDatabaseId);
    } else {
      db = admin.firestore();
    }
    console.log(`[DATABASE] Cloud Firestore initialized via Firebase Admin SDK with Database ID: ${firebaseConfig.firestoreDatabaseId || "(default)"}`);
  } else {
    console.warn("[DATABASE] WARNING: firebase-applet-config.json not found. Firestore features are disabled.");
  }
} catch (dbErr: any) {
  console.error(`[DATABASE] Error initializing Firestore database: ${dbErr.message}`);
}

// In-Memory store
let messages: DiscordMessage[] = [];
const BOT_OWNER_ID = "1364315043700674662";

let botConfig: BotConfig = {
  botToken: process.env.DISCORD_BOT_TOKEN || "",
  channelId: process.env.DISCORD_CHANNEL_ID || "",
  allowedOperators: {},
};

function isAuthorizedOperator(userId: string, username: string, globalName?: string): { authorized: boolean; role?: "mrz" | "mrzadmin" | "mrzmod" } {
  // 1. Bot Owner has ultimate root access (mrzadmin role)
  if (userId === BOT_OWNER_ID) {
    return { authorized: true, role: "mrzadmin" };
  }
  
  // 2. Explicitly added operator in the configuration
  if (botConfig.allowedOperators && botConfig.allowedOperators[userId]) {
    return { authorized: true, role: botConfig.allowedOperators[userId].role };
  }

  // 3. Fallback to hardcoded usernames for backward compatibility
  const usernameLower = username.toLowerCase();
  const globalLower = (globalName || "").toLowerCase();
  
  if (usernameLower === "mrz" || globalLower === "mrz") {
    return { authorized: true, role: "mrz" };
  }
  if (usernameLower === "mrzadmin" || globalLower === "mrzadmin") {
    return { authorized: true, role: "mrzadmin" };
  }
  if (usernameLower === "mrzmod" || globalLower === "mrzmod") {
    return { authorized: true, role: "mrzmod" };
  }

  return { authorized: false };
}
let botStatus: BotStatus = {
  connected: false,
  status: "offline",
  botName: null,
  botAvatarUrl: null,
  error: null,
  monitoredChannel: null,
};
let systemLogs: LogEntry[] = [];

// Session state storage
const sessions = new Map<string, { username: string; role: "admin" | "mod" }>();

interface SseConnection {
  res: express.Response;
  isAdmin: boolean;
}
const sseConnections = new Set<SseConnection>();

// SSE Broadcast helper
function broadcast(payload: RealtimePayload, requireAdmin = false) {
  const payloadString = `data: ${JSON.stringify(payload)}\n\n`;
  sseConnections.forEach((conn) => {
    if (!requireAdmin || conn.isAdmin) {
      try {
        conn.res.write(payloadString);
      } catch (err) {
        console.error("SSE write failure:", err);
      }
    }
  });
}

// Discord Log Channel IDs
const LOG_CHANNELS = {
  CONSOLE: "1507421926207787148",
  CONTENT_UPLOAD: "1507421994298249268",
  CONTENT_DELETE: "1507422028888674496",
  CONTENT_EDIT: "1507422061130289193",
  LOGIN: "1507422132198707311",
  OTHER: "1507422166088683670"
};

let isSendingLog = false;

async function dispatchDiscordLogEmbed(channelId: string, embed: any) {
  if (!discordClient || !discordClient.user) return;
  try {
    const channel = await discordClient.channels.fetch(channelId);
    if (channel && typeof (channel as any).send === "function") {
      await (channel as any).send({ embeds: [embed] });
    }
  } catch (err: any) {
    console.error(`[DISCORD LOGGER EXCEPTION] Failed sending log to channel ${channelId}:`, err.message);
  }
}

// Log helper
function addLog(level: "info" | "warn" | "error", message: string) {
  const log: LogEntry = {
    timestamp: new Date().toISOString(),
    level,
    message,
  };
  systemLogs.unshift(log);
  if (systemLogs.length > 100) systemLogs.pop();
  
  // Stream log immediately to admin clients
  broadcast({ type: "log", data: log }, true);
  console.log(`[${level.toUpperCase()}] ${log.timestamp} - ${message}`);

  // Write log asynchronously to Firestore
  if (db) {
    const logId = "log_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
    db.collection("logs").doc(logId).set(log).catch(() => {
      // Handled silently to prevent loop
    });
  }

  // Dispatch live Discord log to active guilds
  if (discordClient && discordClient.user && !isSendingLog) {
    isSendingLog = true;
    try {
      const colorMap = { info: 0xd97706, warn: 0xf59e0b, error: 0xef4444 };
      const embed = {
        title: `💻 System Console Log [${level.toUpperCase()}]`,
        description: message,
        color: colorMap[level] || 0xd97706,
        timestamp: log.timestamp,
        footer: { text: "MRZ Gallery • Core Engine Monitoring" }
      };
      
      const lowercaseMsg = message.toLowerCase();
      
      // Dispatch to Console Logs channel
      dispatchDiscordLogEmbed(LOG_CHANNELS.CONSOLE, embed);

      // If it's general startup, authentication, seeding, or errors, dispatch to OTHER Logs channel
      if (
        lowercaseMsg.includes("discord client successfully authenticated") ||
        lowercaseMsg.includes("starting discord client connection flow") ||
        lowercaseMsg.includes("teardown") ||
        lowercaseMsg.includes("monitoring") ||
        lowercaseMsg.includes("saved") ||
        lowercaseMsg.includes("synchronizing") ||
        lowercaseMsg.includes("seeded") ||
        level === "error" ||
        level === "warn"
      ) {
        const otherEmbed = {
          title: level === "error" ? "🚨 System Alert / Error" : level === "warn" ? "⚠️ System Warning" : "⚙️ System Core Activity",
          description: message,
          color: level === "error" ? 0xef4444 : level === "warn" ? 0xf59e0b : 0x1d4ed8,
          timestamp: log.timestamp,
          footer: { text: "MRZ Gallery • General Service Monitor" }
        };
        dispatchDiscordLogEmbed(LOG_CHANNELS.OTHER, otherEmbed);
      }
    } catch (err: any) {
      console.error("[DISCORD LOGGER ERROR]", err.message);
    } finally {
      isSendingLog = false;
    }
  }
}

// Persistent message write helper
async function persistNewMessage(msg: DiscordMessage) {
  if (!db) return;
  try {
    await db.collection("messages").doc(msg.id).set(msg);
  } catch (err: any) {
    addLog("error", `Firestore save message failed: ${err.message}`);
  }
}

// Persistent message delete helper
async function persistDeleteMessage(id: string) {
  if (!db) return;
  try {
    await db.collection("messages").doc(id).delete();
  } catch (err: any) {
    addLog("error", `Firestore delete message failed: ${err.message}`);
  }
}

// Load persisted data from both Local files and Cloud Firestore Space
async function loadPersistedData() {
  // First load from local storage files for rapid boot & fallback
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const data = fs.readFileSync(CONFIG_PATH, "utf-8");
      botConfig = JSON.parse(data);
      if (!botConfig.allowedOperators) {
        botConfig.allowedOperators = {};
      }
      addLog("info", "Bot configuration loaded from local storage cache.");
    } else {
      botConfig.allowedOperators = {};
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(botConfig, null, 2));
    }
  } catch (error: any) {
    addLog("error", `Failed to load local config: ${error.message}`);
  }

  try {
    if (fs.existsSync(MESSAGES_PATH)) {
      const data = fs.readFileSync(MESSAGES_PATH, "utf-8");
      const rawMessages = JSON.parse(data);
      if (Array.isArray(rawMessages)) {
        const allowed = ["mrz", "mrzadmin", "mrzmod"];
        messages = rawMessages.filter((m: any) => {
          const authName = (m.authorName || "").toLowerCase();
          const authTag = (m.authorTag || "").toLowerCase().split("#")[0];
          return allowed.includes(authName) || allowed.includes(authTag);
        });
        addLog("info", `Loaded and filtered ${messages.length} authorized messages from local cache.`);
        fs.writeFileSync(MESSAGES_PATH, JSON.stringify(messages, null, 2));
      } else {
        messages = [];
      }
    } else {
      messages = [];
      fs.writeFileSync(MESSAGES_PATH, JSON.stringify(messages, null, 2));
      addLog("info", "Initialized empty local messages cache.");
    }
  } catch (error: any) {
    addLog("error", `Failed to load local messages: ${error.message}`);
  }

  // Next, synchronize configuration and messages from direct Firestore Space
  if (db) {
    try {
      addLog("info", "Synchronizing configuration from Cloud Firestore database...");
      const configDoc = await db.collection("config").doc("bot").get();
      if (configDoc.exists) {
        const remoteConfig = configDoc.data() as BotConfig;
        if (remoteConfig.botToken || remoteConfig.channelId) {
          botConfig = remoteConfig;
          if (!botConfig.allowedOperators) {
            botConfig.allowedOperators = {};
          }
          addLog("info", "Bot configuration successfully synchronized from Firestore.");
        }
      } else {
        // Feed local configuration to database as seed
        await db.collection("config").doc("bot").set(botConfig);
        addLog("info", "Seeded local configuration keys into Firestore database.");
      }
    } catch (err: any) {
      addLog("error", `Firestore config synchronization failed: ${err.message}`);
    }

    try {
      addLog("info", "Synchronizing messages from Cloud Firestore database...");
      const messagesColl = db.collection("messages");
      const q = messagesColl.orderBy("createdAt", "desc").limit(200);
      const querySnapshot = await q.get();
      const remoteMsgs: DiscordMessage[] = [];
      
      querySnapshot.forEach((docSnap) => {
        remoteMsgs.push(docSnap.data() as DiscordMessage);
      });

      if (remoteMsgs.length > 0) {
        messages = remoteMsgs;
        addLog("info", `Successfully synchronized ${messages.length} messages from Firestore database.`);
        fs.writeFileSync(MESSAGES_PATH, JSON.stringify(messages, null, 2));
      } else if (messages.length > 0) {
        addLog("info", `Seeding ${messages.length} local messages into empty Firestore database...`);
        for (const msg of messages) {
          await db.collection("messages").doc(msg.id).set(msg);
        }
        addLog("info", "Completed seeding messages to Firestore.");
      }
    } catch (err: any) {
      addLog("error", `Firestore messages synchronization failed: ${err.message}`);
    }
  }
}

// Save helpers
function saveConfig() {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(botConfig, null, 2));
    if (db) {
      db.collection("config").doc("bot").set(botConfig).catch((err: any) => {
        addLog("error", `Async Firestore config save failed: ${err.message}`);
      });
    }
  } catch (error: any) {
    addLog("error", `Failed to save local config file: ${error.message}`);
  }
}

function saveMessages() {
  try {
    fs.writeFileSync(MESSAGES_PATH, JSON.stringify(messages, null, 2));
  } catch (error: any) {
    addLog("error", `Failed to save local messages file: ${error.message}`);
  }
}



// Discord Client Instance Holder
let discordClient: Client | null = null;

// Build helper for avatarUrl
function getDiscordAvatarUrl(author: any) {
  if (author.avatar) {
    return `https://cdn.discordapp.com/avatars/${author.id}/${author.avatar}.png`;
  }
  const disc = author.discriminator && author.discriminator !== "0" ? parseInt(author.discriminator) : 0;
  return `https://cdn.discordapp.com/embed/avatars/${(disc || parseInt(author.id.slice(-2)) || 0) % 5}.png`;
}

// Update bot status helper
function setStatus(status: BotStatus["status"], errorMsg: string | null = null) {
  botStatus.status = status;
  botStatus.connected = status === "online";
  botStatus.error = errorMsg;
  if (status !== "online") {
    botStatus.botName = null;
    botStatus.botAvatarUrl = null;
    botStatus.monitoredChannel = null;
  }
  
  // Broadcast update to admin front-end instantly
  broadcast({ type: "status", data: botStatus }, true);
}

// Initialize and login Discord Bot
async function startDiscordBot() {
  // Destroy existing client first if any is running
  if (discordClient) {
    addLog("info", "Disconnecting active Discord client...");
    try {
      discordClient.destroy();
    } catch (err: any) {
      addLog("error", `Exception during bot teardown: ${err.message}`);
    }
    discordClient = null;
  }

  const token = botConfig.botToken.trim();
  const channelId = botConfig.channelId.trim();

  if (!token) {
    addLog("warn", "No Discord Bot Token configured. Standing by in offline mode...");
    setStatus("offline");
    return;
  }

  addLog("info", "Starting Discord client connection flow...");
  setStatus("connecting");

  try {
    const client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
      ],
      partials: [Partials.Channel, Partials.Message]
    });

    client.on("ready", async () => {
      addLog("info", `Discord Client successfully authenticated as: ${client.user?.tag}`);
      
      let verifiedChannelName = "General / Unknown";
      let verifiedGuildName = "Unknown Server";

      if (channelId) {
        addLog("info", `Fetching specified Discord channel with ID: ${channelId}...`);
        try {
          const channel = await client.channels.fetch(channelId);
          if (channel) {
            verifiedChannelName = (channel as any).name || "Text Channel";
            verifiedGuildName = (channel as any).guild?.name || "Guild Server";
            addLog("info", `Monitored channel verified! Found '#${verifiedChannelName}' on server '${verifiedGuildName}'.`);
            
            botStatus.monitoredChannel = {
              id: channelId,
              name: verifiedChannelName,
              guildName: verifiedGuildName,
            };
          } else {
            throw new Error("Channel handle was null after resolution");
          }
        } catch (fetchError: any) {
          const warnMsg = `Could not find or load channel ID ${channelId}: ${fetchError.message}. The bot is connected but may not receive messages from this channel. Ensure the bot has permissions to view the channel.`;
          addLog("warn", warnMsg);
          botStatus.monitoredChannel = {
            id: channelId,
            name: "Unreachable / Missing Permissions",
            guildName: "Unknown Guild",
          };
        }
      } else {
        addLog("warn", "No channel ID provided. Bot is connected but stands idle.");
      }

      // Configure Bot Activity status: Streaming "MRZ Offical Website Manager" and custom sub-note "Developed by : Ark Graphics"
      client.user?.setPresence({
        activities: [
          {
            name: "MRZ Offical Website Manager",
            type: ActivityType.Streaming,
            url: "https://mrzoffical.vercel.app", // When clicking 'Watch Now', redirect to this URL
            state: "Developed by : Ark Graphics"
          }
        ],
        status: "online",
      });

      botStatus.botName = client.user?.username || "Discord Sync Bot";
      botStatus.botAvatarUrl = client.user ? getDiscordAvatarUrl(client.user) : null;
      setStatus("online");

      // Register slash commands globally & locally on all guilds for immediate availability
      const commandData = {
        name: "gallery-post",
        description: "Post a highly-styled message card directly to the MRZ Gallery",
        options: [
          {
            name: "content",
            description: "The main text message of your card",
            type: 3, // String
            required: true
          },
          {
            name: "image",
            description: "An optional image attachment to feature on the card",
            type: 11, // Attachment
            required: false
          },
          {
            name: "color",
            description: "Select a custom card border color theme",
            type: 3, // String
            required: false,
            choices: [
              { name: "Emerald Matrix (Green)", value: "emerald" },
              { name: "Crimson Eclipse (Red)", value: "crimson" },
              { name: "Cyberpunk Cyan (Cyan)", value: "cyan" },
              { name: "Premium Amethyst (Purple)", value: "purple" },
              { name: "Solid Gold (Golden Amber)", value: "gold" },
              { name: "Liquid Glass (Amber Slate)", value: "default" }
            ]
          },
          {
            name: "glow",
            description: "Add a premium luminous hover glow effect to the card",
            type: 5, // Boolean
            required: false
          }
        ]
      };

      const cmdOperatorAdd = {
        name: "gallery-operator-add",
        description: "👑 [Owner Only] Grant gallery posting access to a Discord member",
        options: [
          {
            name: "member",
            description: "The member to grant access to",
            type: 6, // User
            required: true
          },
          {
            name: "role",
            description: "Roster classification role for this member",
            type: 3, // String
            required: true,
            choices: [
              { name: "mrz (Standard Operator)", value: "mrz" },
              { name: "mrzmod (Moderator)", value: "mrzmod" },
              { name: "mrzadmin (Administrator)", value: "mrzadmin" }
            ]
          }
        ]
      };

      const cmdOperatorRemove = {
        name: "gallery-operator-remove",
        description: "👑 [Owner Only] Revoke gallery posting access from a Discord member",
        options: [
          {
            name: "member",
            description: "The member to revoke access from",
            type: 6, // User
            required: true
          }
        ]
      };

      const cmdOperatorList = {
        name: "gallery-operator-list",
        description: "List all dynamically authorized gallery operator roles"
      };

      const allCommands = [commandData, cmdOperatorAdd, cmdOperatorRemove, cmdOperatorList];

      try {
        addLog("info", "Registering gallery slash commands globally...");
        await client.application?.commands.set(allCommands);
        addLog("info", "Successfully registered global slash commands.");

        const guilds = await client.guilds.fetch();
        for (const [guildId, guildRef] of guilds) {
          try {
            const guild = await guildRef.fetch();
            await guild.commands.set(allCommands);
            addLog("info", `Registered slash commands locally on server: ${guild.name}`);
          } catch (guildErr: any) {
            console.warn(`[COMMAND SEED SKIP] Guild ID ${guildId} registration skipped: ${guildErr.message}`);
          }
        }
      } catch (cmdErr: any) {
        addLog("error", `Failed to register slash command layouts: ${cmdErr.message}`);
      }
    });

    client.on("messageCreate", async (message) => {
      // Skip own messages to avoid feed feedback loops
      if (message.author.id === client.user?.id) return;

      // Filter for target channel ID
      if (channelId && message.channelId === channelId) {
        // Evaluate dynamic operator authorization permissions
        const authStatus = isAuthorizedOperator(message.author.id, message.author.username, message.author.globalName || undefined);
        if (!authStatus.authorized) {
          addLog("info", `Skipped message from @${message.author.username} since author is not on the allowed roster.`);
          return;
        }

        addLog("info", `Intercepted new message from @${message.author.username} in #${(message.channel as any).name || "linked-channel"}`);

        const rawAttachments = Array.from(message.attachments.values());
        const mappedAttachments = rawAttachments.map((att) => ({
          id: att.id,
          name: att.name,
          url: att.url,
          contentType: att.contentType || null,
          size: att.size,
          width: att.width || undefined,
          height: att.height || undefined,
        }));

        const newMsg: DiscordMessage = {
          id: message.id,
          authorId: message.author.id,
          authorName: message.author.globalName || message.author.username,
          authorTag: message.author.tag,
          authorAvatar: getDiscordAvatarUrl(message.author),
          content: message.content || "",
          attachments: mappedAttachments,
          createdAt: message.createdAt.toISOString(),
          channelId: message.channelId,
          channelName: (message.channel as any).name || "announcements",
        };

        // Insert at beginning
        messages.unshift(newMsg);
        if (messages.length > 100000) {
          const removed = messages.pop();
          if (removed) persistDeleteMessage(removed.id);
        }
        
        saveMessages();
        persistNewMessage(newMsg);
        broadcast({ type: "message", data: newMsg });

        // Dispatch Content Upload Log
        if (discordClient && discordClient.user) {
          const uploadEmbed = {
            title: "📥 Content Upload • Discord Synchronized Message",
            color: 0x10b981, // Emerald green
            timestamp: new Date().toISOString(),
            thumbnail: { url: newMsg.authorAvatar || undefined },
            fields: [
              { name: "Author", value: `**${newMsg.authorName}** (${newMsg.authorTag})`, inline: true },
              { name: "Channel", value: `#${newMsg.channelName} (${newMsg.channelId})`, inline: true },
              { name: "Message ID", value: `\`${newMsg.id}\``, inline: true },
              { name: "Content Preview", value: newMsg.content ? (newMsg.content.length > 500 ? newMsg.content.substring(0, 500) + "..." : newMsg.content) : "*No text content*" },
              { name: "Attachments", value: newMsg.attachments && newMsg.attachments.length > 0 
                ? newMsg.attachments.map(a => `📎 [${a.name}](${a.url})`).join("\n") 
                : "*None*" }
            ],
            footer: { text: "MRZ Gallery • Live Sync Engine" }
          };
          dispatchDiscordLogEmbed(LOG_CHANNELS.CONTENT_UPLOAD, uploadEmbed);
        }
      }
    });

    client.on("interactionCreate", async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      if (interaction.commandName === "gallery-post") {
        // Evaluate dynamic operator authorization permissions
        const authStatus = isAuthorizedOperator(interaction.user.id, interaction.user.username, interaction.user.globalName || undefined);
        if (!authStatus.authorized) {
          await interaction.reply({
            content: `❌ **Access Denied:** You are not on the authorized MRZ operator roster (mrz, mrzadmin, mrzmod).`,
            ephemeral: true
          });
          addLog("info", `Blocked unauthorized /gallery-post command usage attempt from @${interaction.user.username}`);
          return;
        }

        // Acknowledge receipt
        await interaction.deferReply({ ephemeral: false });

        try {
          const content = interaction.options.getString("content", true);
          const imageAttachment = interaction.options.getAttachment("image");
          const customColor = interaction.options.getString("color") || undefined;
          const customGlow = interaction.options.getBoolean("glow") || false;

          const mappedAttachments: any[] = [];
          if (imageAttachment) {
            mappedAttachments.push({
              id: imageAttachment.id,
              name: imageAttachment.name,
              url: imageAttachment.url,
              contentType: imageAttachment.contentType || "image/png",
              size: imageAttachment.size,
              width: imageAttachment.width || undefined,
              height: imageAttachment.height || undefined
            });
          }

          const newMsg: DiscordMessage = {
            id: interaction.id,
            authorId: interaction.user.id,
            authorName: interaction.user.globalName || interaction.user.username,
            authorTag: interaction.user.tag,
            authorAvatar: getDiscordAvatarUrl(interaction.user),
            content,
            attachments: mappedAttachments,
            createdAt: new Date().toISOString(),
            channelId: interaction.channelId || "slash-command",
            channelName: (interaction.channel as any)?.name || "slash-channel",
            customBoxColor: customColor,
            customGlow: customGlow
          };

          // Cache locally
          messages.unshift(newMsg);
          if (messages.length > 100000) {
            const removed = messages.pop();
            if (removed) persistDeleteMessage(removed.id);
          }

          saveMessages();
          await persistNewMessage(newMsg);
          broadcast({ type: "message", data: newMsg });

          // Send premium embed reply
          const themeColorMap: Record<string, { hex: string, dec: number }> = {
            emerald: { hex: "#10b981", dec: 0x10b981 },
            crimson: { hex: "#ef4444", dec: 0xef4444 },
            cyan: { hex: "#06b6d4", dec: 0x06b6d4 },
            purple: { hex: "#a855f7", dec: 0xa855f7 },
            gold: { hex: "#f59e0b", dec: 0xf59e0b },
            default: { hex: "#fbbf24", dec: 0xfbbf24 }
          };

          const selectedTheme = themeColorMap[customColor || "default"] || themeColorMap.default;
          const colorDecimal = selectedTheme.dec;

          const embed = {
            title: "🌟 Published Successfully!",
            description: `Your custom gallery card has been sent to the live web interface.`,
            color: colorDecimal,
            fields: [
              { name: "Content Preview", value: content.length > 300 ? content.substring(0, 300) + "..." : content },
              { name: "Accent Highlight Color", value: `\`${customColor || "Default Slate"}\``, inline: true },
              { name: "Card Shadow Glow", value: customGlow ? "🌟 Active" : "❌ Inactive", inline: true }
            ],
            image: imageAttachment ? { url: imageAttachment.url } : undefined,
            timestamp: new Date().toISOString(),
            footer: { text: "MRZ Gallery Core System" }
          };

          await interaction.editReply({ embeds: [embed] });

          // Dispatch Content Upload Log
          const uploadEmbed = {
            title: "📤 Content Upload • Slash Command Action",
            color: colorDecimal,
            timestamp: new Date().toISOString(),
            thumbnail: { url: newMsg.authorAvatar || undefined },
            fields: [
              { name: "Operator Username", value: `**${newMsg.authorName}** (${newMsg.authorTag})`, inline: true },
              { name: "Command Executed In", value: `#${newMsg.channelName} (${newMsg.channelId})`, inline: true },
              { name: "Post Record ID", value: `\`${newMsg.id}\``, inline: true },
              { name: "Content Preview", value: content },
              { name: "Box Highlight Theme", value: customColor || "*Default*", inline: true },
              { name: "Shadow Glow Layer", value: customGlow ? "🌟 Enabled" : "❌ Disabled", inline: true },
              { name: "Attached Media", value: mappedAttachments.length > 0
                ? mappedAttachments.map(a => `📎 [${a.name}](${a.url})`).join("\n")
                : "*None*" }
            ],
            footer: { text: "MRZ Gallery • Automated Verification System" }
          };
          dispatchDiscordLogEmbed(LOG_CHANNELS.CONTENT_UPLOAD, uploadEmbed);

        } catch (postErr: any) {
          addLog("error", `Failed handling /gallery-post command: ${postErr.message}`);
          await interaction.editReply({ content: `❌ **Error processing command requested:** ${postErr.message}` });
        }
      }

      // Handler for /gallery-operator-add
      if (interaction.commandName === "gallery-operator-add") {
        if (interaction.user.id !== BOT_OWNER_ID) {
          await interaction.reply({
            content: `❌ **Access Denied:** Only the designated MRZ Bot Owner can manage operators.`,
            ephemeral: true
          });
          return;
        }

        await interaction.deferReply({ ephemeral: true });

        try {
          const targetUser = interaction.options.getUser("member", true);
          const role = interaction.options.getString("role", true) as "mrz" | "mrzadmin" | "mrzmod";

          if (!botConfig.allowedOperators) {
            botConfig.allowedOperators = {};
          }

          botConfig.allowedOperators[targetUser.id] = {
            id: targetUser.id,
            username: targetUser.username,
            role: role
          };

          saveConfig();
          addLog("info", `Bot Owner successfully added operator ${targetUser.username} (${targetUser.id}) as role ${role}`);

          await interaction.editReply({
            content: `✅ **Success:** Fully granted access to Discord Member **${targetUser.username}** as \`${role}\`.`
          });
        } catch (addErr: any) {
          addLog("error", `Failed to add operator: ${addErr.message}`);
          await interaction.editReply({
            content: `❌ **Error:** Failed to record change: ${addErr.message}`
          });
        }
      }

      // Handler for /gallery-operator-remove
      if (interaction.commandName === "gallery-operator-remove") {
        if (interaction.user.id !== BOT_OWNER_ID) {
          await interaction.reply({
            content: `❌ **Access Denied:** Only the designated MRZ Bot Owner can manage operators.`,
            ephemeral: true
          });
          return;
        }

        await interaction.deferReply({ ephemeral: true });

        try {
          const targetUser = interaction.options.getUser("member", true);

          if (!botConfig.allowedOperators || !botConfig.allowedOperators[targetUser.id]) {
            await interaction.editReply({
              content: `⚠️ Operator **${targetUser.username}** was not found in the dynamic list of operators.`
            });
            return;
          }

          delete botConfig.allowedOperators[targetUser.id];
          saveConfig();
          addLog("info", `Bot Owner successfully revoked operator access for ${targetUser.username} (${targetUser.id})`);

          await interaction.editReply({
            content: `✅ **Success:** Fully revoked operator access from **${targetUser.username}**.`
          });
        } catch (removeErr: any) {
          addLog("error", `Failed to revoke operator access: ${removeErr.message}`);
          await interaction.editReply({
            content: `❌ **Error:** Failed to record change: ${removeErr.message}`
          });
        }
      }

      // Handler for /gallery-operator-list
      if (interaction.commandName === "gallery-operator-list") {
        await interaction.deferReply({ ephemeral: true });

        try {
          const hardcodedList = ["mrz", "mrzadmin", "mrzmod"];
          let responseText = `⚙️ **MRZ Gallery Roster Monitor**\n\n`;
          
          responseText += `👑 **System Bot Owner:**\n`;
          responseText += `• <@${BOT_OWNER_ID}> (\`admin-root\`)\n\n`;

          responseText += `📌 **Traditional Username Access (Legacy):**\n`;
          hardcodedList.forEach(u => {
            responseText += `• Username: \`${u}\`\n`;
          });
          responseText += `\n`;

          responseText += `🌟 **Dynamically Approved Operators:**\n`;
          const ops = botConfig.allowedOperators ? Object.values(botConfig.allowedOperators) : [];
          if (ops.length === 0) {
            responseText += `*No dynamic operators added yet. The Bot Owner can grant access with \`/gallery-operator-add\`.*\n`;
          } else {
            ops.forEach(op => {
              responseText += `• <@${op.id}> (\`${op.username}\`) - Role: \`${op.role}\`\n`;
            });
          }

          await interaction.editReply({
            content: responseText
          });
        } catch (listErr: any) {
          await interaction.editReply({
            content: `❌ **Error loading registry list:** ${listErr.message}`
          });
        }
      }
    });

    client.on("error", (err: any) => {
      addLog("error", `Fatal socket error reported by Discord Gateway: ${err.message}`);
      setStatus("error", err.message);
    });

    client.on("shardError", (err: any) => {
      addLog("error", `Gateway connection issue (ShardError): ${err.message}`);
    });

    // Handle invalid token / connection failure
    discordClient = client;
    await client.login(token);

  } catch (error: any) {
    addLog("error", `Bot login thread crashed: ${error.message}`);
    setStatus("error", error.message || "Failed to log in. Please check your token.");
    discordClient = null;
  }
}

// Parse json structures with 60mb limit to handle POV media files (images, audio, videos)
app.use(express.json({ limit: "60mb" }));
app.use(express.urlencoded({ limit: "60mb", extended: true }));

// Serve uploaded media files publicly
app.use("/uploads", express.static(UPLOADS_DIR));

// Configured credentials list
const USERS: { username: string; password: string; role: "admin" | "mod" }[] = [
  { username: "Mrz", password: "mrz001", role: "admin" },
  { username: "mrzadmin", password: "adminmrz123", role: "admin" },
  { username: "mrzmod", password: "modmrz321", role: "mod" }
];

// Admin/Moderator Authorization Middleware
function authenticateAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const token = req.headers["x-admin-token"] || 
                req.query.token || 
                req.body?.token || 
                (req.headers.authorization?.startsWith("Bearer ") ? req.headers.authorization.substring(7) : undefined);
  if (token && typeof token === "string" && sessions.has(token)) {
    next();
  } else {
    addLog("warn", `Unauthorized access attempt to ${req.originalUrl} - Method: ${req.method}, Token Present: ${!!token}`);
    res.status(401).json({ error: "Unauthorized access" });
  }
}

// Strict Full-Administration authorization check - only "mrzadmin" has full admin clearance
function requireFullAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const token = req.headers["x-admin-token"] || 
                req.query.token || 
                req.body?.token || 
                (req.headers.authorization?.startsWith("Bearer ") ? req.headers.authorization.substring(7) : undefined);
  if (token && typeof token === "string" && sessions.has(token)) {
    const sessionInfo = sessions.get(token);
    if (sessionInfo && sessionInfo.username?.toLowerCase() === "mrzadmin") {
      return next();
    }
    addLog("warn", `Forbidden administration action attempt on ${req.originalUrl} by ${sessionInfo?.username || "unknown"}`);
  } else {
    addLog("warn", `Unauthorized full-admin access attempt on ${req.originalUrl} - Method: ${req.method}, Token Present: ${!!token}`);
  }
  res.status(403).json({ error: "Forbidden: Full administration credentials required" });
}

// Open / Public Endpoints
app.get("/api/messages", (req, res) => {
  res.json(messages);
});

// Auth Administration Endpoints
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  const cleanUsername = typeof username === "string" ? username.trim() : "";
  const cleanPassword = typeof password === "string" ? password.trim() : "";
  
  const matchedUser = USERS.find(
    (u) => u.username.toLowerCase() === cleanUsername.toLowerCase() && u.password === cleanPassword
  );

  // Extract IP Address securely
  let rawIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || req.ip || "Unknown IP";
  const ipAddress = Array.isArray(rawIp) ? rawIp[0] : rawIp;

  if (matchedUser) {
    const sessionToken = "session_" + Math.random().toString(36).substring(2, 12) + Date.now().toString(36);
    sessions.set(sessionToken, { username: matchedUser.username, role: matchedUser.role });
    addLog("info", `Login success: ${matchedUser.username} authenticated as role '${matchedUser.role}'.`);

    // Dispatch Login Success Log Embed
    if (discordClient && discordClient.user) {
      const loginEmbed = {
        title: "🔐 Admin Portal Login • Session Opened",
        color: 0x8b5cf6, // Royal Velvet Violet
        timestamp: new Date().toISOString(),
        fields: [
          { name: "Authenticated User", value: `**${matchedUser.username}**`, inline: true },
          { name: "Access Role", value: `\`${matchedUser.role}\``, inline: true },
          { name: "Remote IP Address", value: `\`${ipAddress}\``, inline: true },
          { name: "Gate Authorization", value: "🟢 SUCCESSFUL_AUTHENTICATION", inline: true }
        ],
        footer: { text: "MRZ Gallery • Authentication Log" }
      };
      dispatchDiscordLogEmbed(LOG_CHANNELS.LOGIN, loginEmbed);
    }

    res.json({ 
      success: true, 
      token: sessionToken, 
      username: matchedUser.username, 
      role: matchedUser.role 
    });
  } else {
    addLog("warn", `Failed login attempt for user: '${username}'`);

    // Dispatch Login Fail Log Embed
    if (discordClient && discordClient.user) {
      const loginFailEmbed = {
        title: "🚨 Admin Portal Warning • Unverified Access Blocked",
        color: 0xef4444, // Red
        timestamp: new Date().toISOString(),
        fields: [
          { name: "Attempted Username", value: `**${username || "None"}**`, inline: true },
          { name: "Remote IP Address", value: `\`${ipAddress}\``, inline: true },
          { name: "Status Alert", value: "🔴 UNAUTHORIZED_ATTEMPT", inline: true }
        ],
        footer: { text: "MRZ Gallery • Intrusion Prevention System" }
      };
      dispatchDiscordLogEmbed(LOG_CHANNELS.LOGIN, loginFailEmbed);
    }

    res.status(401).json({ error: "Invalid credentials" });
  }
});

app.post("/api/logout", (req, res) => {
  const token = req.headers["x-admin-token"];
  if (token && typeof token === "string") {
    sessions.delete(token);
    addLog("info", "User session closed.");
  }
  res.json({ success: true });
});

app.get("/api/verify-token", (req, res) => {
  const token = req.headers["x-admin-token"] || req.query.token;
  if (token && typeof token === "string" && sessions.has(token)) {
    const info = sessions.get(token);
    res.json({ success: true, username: info?.username, role: info?.role });
  } else {
    res.json({ success: false });
  }
});

// Protected Information, Config, and Controls Endpoints (Require full Admin role)
app.get("/api/config", requireFullAdmin, (req, res) => {
  // Return masked config for security
  const maskedToken = botConfig.botToken 
    ? botConfig.botToken.substring(0, 12) + "•".repeat(Math.max(10, botConfig.botToken.length - 12))
    : "";
  res.json({
    botToken: maskedToken,
    hasToken: !!botConfig.botToken,
    channelId: botConfig.channelId,
  });
});

app.post("/api/config", requireFullAdmin, async (req, res) => {
  const { botToken, channelId } = req.body;

  let updated = false;
  if (channelId !== undefined) {
    botConfig.channelId = channelId.trim();
    updated = true;
  }

  if (botToken !== undefined && botToken.trim() !== "") {
    // Check if they updated a masked mock token or clean new text
    const cleanToken = botToken.trim();
    if (!cleanToken.includes("•")) {
      botConfig.botToken = cleanToken;
      updated = true;
    }
  } else if (botToken === "") {
    botConfig.botToken = "";
    updated = true;
  }

  if (updated) {
    saveConfig();
    addLog("info", `Configuration saved. Linking channel ${botConfig.channelId || "<none>"}`);
    // Async restart bot trigger
    startDiscordBot().catch((e) => {
      addLog("error", `Async connection trigger failed: ${e.message}`);
    });
  }

  res.json({ success: true, config: { channelId: botConfig.channelId, hasToken: !!botConfig.botToken } });
});

app.get("/api/status", requireFullAdmin, (req, res) => {
  res.json(botStatus);
});

app.get("/api/logs", requireFullAdmin, (req, res) => {
  res.json(systemLogs);
});

app.post("/api/clear", requireFullAdmin, async (req, res) => {
  const adminToken = (req.headers["x-admin-token"] || req.query.token || req.body?.token) as string;
  const sessionInfo = sessions.get(adminToken);
  const operatorName = sessionInfo ? sessionInfo.username : "Administrator";

  messages = [];
  saveMessages();
  
  if (db) {
    try {
      const messagesColl = db.collection("messages");
      const querySnapshot = await messagesColl.get();
      querySnapshot.forEach((docSnap) => {
        docSnap.ref.delete().catch((e: any) => console.error("Firestore board clear sub-error:", e));
      });
      addLog("info", "Purged message records from Firestore database collection.");
    } catch (err: any) {
      addLog("error", `Firestore board clear failed: ${err.message}`);
    }
  }

  broadcast({ type: "messages_init", data: [] });
  addLog("info", "Board message list was cleared by user command.");

  // Dispatch Bulk Delete Log
  if (discordClient && discordClient.user) {
    const clearEmbed = {
      title: "🧹 Bulk Content Purge • Entire Board Cleared",
      color: 0x7f1d1d, // Deep Rich Crimson Red
      timestamp: new Date().toISOString(),
      fields: [
        { name: "Operator", value: `**${operatorName}**`, inline: true },
        { name: "Action", value: "Purged all cached messages locally & from Firestore database", inline: true }
      ],
      footer: { text: "MRZ Gallery • Security Log" }
    };
    dispatchDiscordLogEmbed(LOG_CHANNELS.CONTENT_DELETE, clearEmbed);
  }

  res.json({ success: true });
});

// File upload handler - converts base64 payload to static container asset
app.post("/api/upload", authenticateAdmin, (req, res) => {
  const { fileName, fileType, data } = req.body;
  if (!fileName || !data) {
    return res.status(400).json({ error: "Missing uploaded file stream details" });
  }

  try {
    const base64Clean = data.includes(";base64,") ? data.split(";base64,")[1] : data;
    const buffer = Buffer.from(base64Clean, "base64");
    
    const ext = path.extname(fileName) || ".png";
    const filenameOnly = path.basename(fileName, ext).replace(/[^a-zA-Z0-9]/g, "_");
    const uniqueName = `${filenameOnly}_${Date.now()}${ext}`;
    
    const filePath = path.join(UPLOADS_DIR, uniqueName);
    fs.writeFileSync(filePath, buffer);
    
    const downloadUrl = `/uploads/${uniqueName}`;
    addLog("info", `File successfully uploaded statically -> ${uniqueName} (${buffer.length} bytes)`);
    res.json({ 
      success: true, 
      url: downloadUrl, 
      size: buffer.length, 
      name: fileName, 
      contentType: fileType 
    });
  } catch (err: any) {
    addLog("error", `File upload failed: ${err.message}`);
    res.status(500).json({ error: `Upload thread exception: ${err.message}` });
  }
});

// Large-file chunked uploader supporting uploads up to 3GB size safely without container RAM exhaustion
app.post("/api/upload-chunked", authenticateAdmin, (req, res) => {
  const { fileName, fileType, chunkIndex, totalChunks, uploadId, data } = req.body;
  
  if (!fileName || data === undefined || uploadId === undefined || chunkIndex === undefined || totalChunks === undefined) {
    return res.status(400).json({ error: "Missing chunk upload parameters" });
  }

  try {
    const base64Clean = data.includes(";base64,") ? data.split(";base64,")[1] : data;
    const buffer = Buffer.from(base64Clean, "base64");
    
    const safeUploadId = uploadId.replace(/[^a-zA-Z0-9]/g, "_");
    const safeFileName = path.basename(fileName).replace(/[^a-zA-Z0-9.-]/g, "_");
    const tempFilePath = path.join(UPLOADS_DIR, `part_${safeUploadId}_${safeFileName}`);

    if (chunkIndex === 0) {
      fs.writeFileSync(tempFilePath, buffer);
    } else {
      fs.appendFileSync(tempFilePath, buffer);
    }

    if (chunkIndex === totalChunks - 1) {
      const ext = path.extname(fileName) || ".mp4";
      const filenameOnly = path.basename(safeFileName, ext).replace(/[^a-zA-Z0-9]/g, "_");
      const uniqueName = `${filenameOnly}_${Date.now()}${ext}`;
      const finalPath = path.join(UPLOADS_DIR, uniqueName);
      
      fs.renameSync(tempFilePath, finalPath);
      
      const downloadUrl = `/uploads/${uniqueName}`;
      const finalSize = fs.statSync(finalPath).size;
      addLog("info", `Chuncked file upload completed -> ${uniqueName} (${finalSize} bytes)`);
      
      res.json({
        success: true,
        completed: true,
        url: downloadUrl,
        size: finalSize,
        name: fileName,
        contentType: fileType
      });
    } else {
      res.json({
        success: true,
        completed: false,
        message: `Chunk ${chunkIndex + 1}/${totalChunks} received`
      });
    }
  } catch (err: any) {
    addLog("error", `Chunk upload anomaly at index ${chunkIndex}: ${err.message}`);
    res.status(500).json({ error: `Chunk transfer thread crash: ${err.message}` });
  }
});

// Sends a real-time customized manual operator message to the gallery synced feed
app.post("/api/custom-message", authenticateAdmin, (req, res) => {
  const { authorName, authorTag, authorAvatar, content, attachments, customBoxColor, customGlow } = req.body;
  
  const token = (req.headers["x-admin-token"] || req.query.token) as string;
  const sessionInfo = sessions.get(token);
  const operatorName = sessionInfo ? sessionInfo.username : "Operator";

  const newMsg: DiscordMessage = {
    id: "user_msg_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
    authorId: "operator_" + (sessionInfo?.username || "mod"),
    authorName: authorName ? authorName.trim() : "MRZ Admin",
    authorTag: authorTag ? authorTag.trim() : "MRZ#1234",
    authorAvatar: authorAvatar || "https://i.imgur.com/uL8SqeX.jpeg",
    content: content || "",
    attachments: attachments || [],
    createdAt: new Date().toISOString(),
    channelId: botConfig.channelId || "mrz-dispatch",
    channelName: "mrz-webpage-dispatch",
    customBoxColor: customBoxColor || "default",
    customGlow: !!customGlow
  };

  messages.unshift(newMsg);
  if (messages.length > 100000) {
    const removed = messages.pop();
    if (removed) persistDeleteMessage(removed.id);
  }
  
  saveMessages();
  persistNewMessage(newMsg);
  broadcast({ type: "message", data: newMsg });
  addLog("info", `Manual board broadcast posted by ${operatorName} as "${newMsg.authorName}"`);

  // Dispatch Content Upload Log
  if (discordClient && discordClient.user) {
    const uploadEmbed = {
      title: "📤 Content Upload • Manual Operator Message",
      color: 0x10b981, // Emerald green
      timestamp: new Date().toISOString(),
      thumbnail: { url: newMsg.authorAvatar || undefined },
      fields: [
        { name: "Operator", value: `**${operatorName}**`, inline: true },
        { name: "Author Persona", value: `**${newMsg.authorName}** (${newMsg.authorTag})`, inline: true },
        { name: "Message ID", value: `\`${newMsg.id}\``, inline: true },
        { name: "Content Preview", value: newMsg.content ? (newMsg.content.length > 500 ? newMsg.content.substring(0, 500) + "..." : newMsg.content) : "*No text content*" },
        { name: "Box Color / Glow", value: `${newMsg.customBoxColor || "default"} / ${newMsg.customGlow ? "🌟 Enabled" : "❌ Disabled"}`, inline: true },
        { name: "Attachments", value: newMsg.attachments && newMsg.attachments.length > 0
          ? newMsg.attachments.map(a => `📎 [${a.name}](${a.url})`).join("\n")
          : "*None*" }
      ],
      footer: { text: "MRZ Gallery • Admin Interface" }
    };
    dispatchDiscordLogEmbed(LOG_CHANNELS.CONTENT_UPLOAD, uploadEmbed);
  }

  res.json({ success: true, message: newMsg });
});

// Delete message individually
app.delete("/api/messages/:id", authenticateAdmin, (req, res) => {
  const { id } = req.params;
  const initialLength = messages.length;
  const deletedMsg = messages.find(m => m.id === id);
  const token = (req.headers["x-admin-token"] || req.query.token) as string;
  const sessionInfo = sessions.get(token);
  const operatorName = sessionInfo ? sessionInfo.username : "Admin/Mod";

  messages = messages.filter(m => m.id !== id);
  if (messages.length < initialLength) {
    saveMessages();
    persistDeleteMessage(id);
    broadcast({ type: "message_delete", data: id });
    addLog("info", `Moderated & deleted individual message reference [ID: ${id}]`);

    // Dispatch Content Delete Log
    if (deletedMsg && discordClient && discordClient.user) {
      const deleteEmbed = {
        title: "🗑️ Content Deleted • Individual Message Remove",
        color: 0x7f1d1d, // Deep Rich Crimson Red
        timestamp: new Date().toISOString(),
        thumbnail: { url: deletedMsg.authorAvatar || undefined },
        fields: [
          { name: "Operator", value: `**${operatorName}**`, inline: true },
          { name: "Original Author", value: `**${deletedMsg.authorName}** (${deletedMsg.authorTag})`, inline: true },
          { name: "Message ID", value: `\`${deletedMsg.id}\``, inline: true },
          { name: "Original Content", value: deletedMsg.content ? (deletedMsg.content.length > 500 ? deletedMsg.content.substring(0, 500) + "..." : deletedMsg.content) : "*No text content*" }
        ],
        footer: { text: "MRZ Gallery • Security Log" }
      };
      dispatchDiscordLogEmbed(LOG_CHANNELS.CONTENT_DELETE, deleteEmbed);
    }

    res.json({ success: true });
  } else {
    res.status(404).json({ error: "Message not found" });
  }
});

// Edit/update message individually (name, profile, timestamps, styling, content)
app.patch("/api/messages/:id", requireFullAdmin, (req, res) => {
  const { id } = req.params;
  const msgIndex = messages.findIndex(m => m.id === id);
  if (msgIndex !== -1) {
    const { token, ...fieldsToUpdate } = req.body;
    const oldMsg = { ...messages[msgIndex] };
    const updatedMsg = { ...messages[msgIndex], ...fieldsToUpdate };
    
    const adminToken = (req.headers["x-admin-token"] || req.query.token || token) as string;
    const sessionInfo = sessions.get(adminToken);
    const operatorName = sessionInfo ? sessionInfo.username : "Administrator";

    messages[msgIndex] = updatedMsg;
    saveMessages();
    persistNewMessage(updatedMsg);
    broadcast({ type: "message_update", data: updatedMsg });
    addLog("info", `Moderated & updated individual message reference [ID: ${id}]`);

    // Dispatch Content Edit Log
    if (discordClient && discordClient.user) {
      const editEmbed = {
        title: "✏️ Content Edited • Individual Message Updated",
        color: 0x1d4ed8, // Classic Royal Sapphire Blue
        timestamp: new Date().toISOString(),
        thumbnail: { url: updatedMsg.authorAvatar || undefined },
        fields: [
          { name: "Operator", value: `**${operatorName}**`, inline: true },
          { name: "Message ID", value: `\`${updatedMsg.id}\``, inline: true },
          { name: "Author Persona (Post-Edit)", value: `**${updatedMsg.authorName}** (${updatedMsg.authorTag})`, inline: true },
          { name: "Before Edit Content", value: oldMsg.content ? (oldMsg.content.length > 250 ? oldMsg.content.substring(0, 250) + "..." : oldMsg.content) : "*No text content*" },
          { name: "After Edit Content", value: updatedMsg.content ? (updatedMsg.content.length > 250 ? updatedMsg.content.substring(0, 250) + "..." : updatedMsg.content) : "*No text content*" },
          { name: "Updated Fields Triggered", value: Object.keys(fieldsToUpdate).join(", ") || "none", inline: true }
        ],
        footer: { text: "MRZ Gallery • Security Log" }
      };
      dispatchDiscordLogEmbed(LOG_CHANNELS.CONTENT_EDIT, editEmbed);
    }

    res.json({ success: true, message: updatedMsg });
  } else {
    res.status(404).json({ error: "Message not found" });
  }
});

// Server-Sent Events stream routing
app.get("/api/stream", (req, res) => {
  const token = req.query.token as string;
  const isAdmin = !!(token && sessions.has(token));

  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
  });
  res.write("\n");

  const connection: SseConnection = { res, isAdmin };
  sseConnections.add(connection);
  
  // Send active messages and logs for synchronization
  res.write(`data: ${JSON.stringify({ type: "messages_init", data: messages })}\n\n`);
  
  if (isAdmin) {
    res.write(`data: ${JSON.stringify({ type: "status", data: botStatus })}\n\n`);
    res.write(`data: ${JSON.stringify({ type: "log", data: { timestamp: new Date().toISOString(), level: "info", message: "Console stream connected with administrator privileges." } })}\n\n`);
  }

  addLog("info", `Web-client (${isAdmin ? "Admin" : "Viewer"}) connected to active stream. Total listening tabs: ${sseConnections.size}`);

  req.on("close", () => {
    sseConnections.delete(connection);
    addLog("info", `Web-client (${isAdmin ? "Admin" : "Viewer"}) closed connection. Remaining listening tabs: ${sseConnections.size}`);
  });
});

// Setup Vite or production static assets serving, wait for data sync, and boot the bot
async function startServer() {
  // Sync all configurations and messages with direct Cloud Firestore db first
  await loadPersistedData();

  // Auto-seed active token and standby channels if none exists to guarantee instant startup
  if (!botConfig.botToken || botConfig.botToken.trim() === "") {
    botConfig.botToken = "MTUwNzMzMjQ4ODg1MzMyNzkyMg.GnHMWP.x7XOVHtr6SCUmcvlwTVA7eD9a1UbbfBtoisTCE";
    if (!botConfig.channelId || botConfig.channelId.trim() === "") {
      // Use standard channel ID requested by user (e.g. Console Logs or the target gallery monitored channel)
      botConfig.channelId = "1507421926207787148";
    }
    saveConfig();
    addLog("info", "Seeded user Discord Bot token automatically into startup configuration.");
  }

  // Try to start the Discord Bot once configurations are fully synced
  if (botConfig.botToken) {
    startDiscordBot().catch((err) => {
      console.error("Startup Discord client failure:", err);
    });
  }

  if (process.env.NODE_ENV !== "production") {
    addLog("info", "Starting application in Sandbox Development environment...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    addLog("info", "Starting application in Production environment...");
    const distPath = path.join(currentDir, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    addLog("info", `Platform gateway server running on port: ${PORT}`);
  });
}

startServer();
